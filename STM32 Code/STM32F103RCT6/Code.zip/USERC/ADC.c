#include "ADC.h"

void ADC1_Init(void)//ADC1初始化
{
    GPIO_InitTypeDef GPIO_InitStructure;
    ADC_InitTypeDef ADC_InitStructure;

    /* ADCCLK = PCLK2/6 */
    RCC_ADCCLKConfig(RCC_PCLK2_Div6); 
    
    /* Enable ADC1, and GPIOA clocks */
    /* 使能ADC1 GPIOA时钟 */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1| RCC_APB2Periph_GPIOA, ENABLE);
    
    /* Configure PA1 (ADC Channel) as analog inputs */
    /* 配置ADC 通道1 通道2 PA1 PA2 模拟输入引脚 */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    /* ADC1 configuration */
    /* ADC1 配置 */
    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;//独立模式
    ADC_InitStructure.ADC_ScanConvMode = DISABLE;//扫描模式
    ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;//单次转换
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;//软件触发
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;//数据右对齐
    ADC_InitStructure.ADC_NbrOfChannel = 2;//双通道
    ADC_Init(ADC1, &ADC_InitStructure);   

    /* Enable ADC1 */
    /* 使能 ADC1 */
    ADC_Cmd(ADC1, ENABLE);

    /* Enable ADC1 reset calibration register */
    /* 使能ADC1复位校准寄存器 */
    ADC_ResetCalibration(ADC1);
    /* Check the end of ADC1 reset calibration register */
    /* 检查ADC1复位校准寄存器的末端 */
    while(ADC_GetResetCalibrationStatus(ADC1));

    /* Start ADC1 calibration */
    /* 启动 ADC1 校准 */
    ADC_StartCalibration(ADC1);
    /* Check the end of ADC1 calibration */
    /* 检查ADC1校准结束 */
    while(ADC_GetCalibrationStatus(ADC1));
}

uint16_t ADC1_Result(unsigned int Channel)//获取ADC通道转换数据
{
    /* ADC1 regular channels configuration */
    /* ADC1 规则通道配置 */
    ADC_RegularChannelConfig(ADC1, Channel, 1, ADC_SampleTime_55Cycles5);
    /* Start ADC1 Software Conversion */
    /* 启动 ADC1 软件转换 */ 
    ADC_SoftwareStartConvCmd(ADC1, ENABLE); 
    
    while(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET);
    return (ADC_GetConversionValue(ADC1));
}

uint16_t ADC1_Result_Average(unsigned int Channel, unsigned int Times)//获取ADC通道数据平均值
{
    int i;
    uint16_t Total = 0;
    
    for(i = 0; i < Times; i++)
    {
        Total += ADC1_Result(Channel);
				Delay_us(5000);
    }
     return (Total / Times);
}

void JoyStick_X_Y_Key_Data(void)//获取JoyStick X Y轴数据 并打印相关信息到串口
{
    uint16_t ADC1_X, ADC1_Y;
    int X, Y;
    
    ADC1_X = ADC1_Result_Average(ADC_Channel_1, 10);//获取ADC1 通道1 的10次数据平均值
    ADC1_Y = ADC1_Result_Average(ADC_Channel_2, 10);//获取ADC1 通道2 的10次数据平均值
    
    X = (ADC1_X * 3.3 / 4096);//转换数据 便于后面各个状态判断
    Y = (ADC1_Y * 3.3 / 4096);//转换数据 便于后面各个状态判断
    
		/* JoyStick XY轴状态判断 */
		if(X == 2 && Y == 3)
		{
			printf("%d\n",ADC1_X);
			printf("%d\n",ADC1_Y);
			printf("Up!\n");
		}
		else if(X == 2 && Y == 0)
		{
			printf("%d\n",ADC1_X);
			printf("%d\n",ADC1_Y);
			printf("Down!\n");
		}
		else if(X == 3 && Y == 2)
		{
			printf("%d\n",ADC1_X);
			printf("%d\n",ADC1_Y);
			printf("Right!\n");
		}
		else if(X == 0 && Y == 2)
		{
			printf("%d\n",ADC1_X);
			printf("%d\n",ADC1_Y);
			printf("Left!\n");
		}
		else if(X == 3 && Y == 3)
		{
			printf("%d\n",ADC1_X);
			printf("%d\n",ADC1_Y);
			printf("Right_Up!\n");
		}
		else if(X == 0 && Y == 3)
		{
			printf("%d\n",ADC1_X);
			printf("%d\n",ADC1_Y);
			printf("Left_Up!\n");
		}
		else if(X == 3 && Y == 0)
		{
			printf("%d\n",ADC1_X);
			printf("%d\n",ADC1_Y);
			printf("Right_Down!\n");
		}
		else if(X == 0 && Y == 0)
		{
			printf("%d\n",ADC1_X);
			printf("%d\n",ADC1_Y);
			printf("Left_Down!\n");
		}
}
