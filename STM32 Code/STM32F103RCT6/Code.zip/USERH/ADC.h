#ifndef __ADC_H__
#define __ADC_H__

#include "stm32f10x.h"
#include "UART.h"
#include "SysTick.h"

void ADC1_Init(void);//ADC1初始化
uint16_t ADC1_Result(unsigned int Channel);//获取ADC 通道转换数据
uint16_t ADC1_Result_Average(unsigned int Channel, unsigned int Times);//获取ADC通道数据平均值
void JoyStick_X_Y_Key_Data(void);//获取JoyStick X Y轴数据 并打印相关信息到串口
    
#endif
